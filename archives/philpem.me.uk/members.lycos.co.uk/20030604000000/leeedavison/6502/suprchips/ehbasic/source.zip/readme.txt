
 The two files in this archive are the complete source to get EhBASIC running on the
 Mitsubishi 38067 micro in external memory.

bios.asm

 This provides the support routines for EhBASIC74, the startup choice menu and a very
 basic machine code monitor. This is the file to assemble to create a ROM for the
 micro as basic.asm is a .include file in the source.

basic.asm

 An extended version of EhBASIC that provides high level support for the I/O available
 in the 38067.
