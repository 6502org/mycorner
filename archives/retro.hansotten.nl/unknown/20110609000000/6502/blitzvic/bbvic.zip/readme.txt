
 The 6502 code in this code was originally from the pascal source for ..

  ED64 - HOW TO WRITE A COMMODORE 64 EMULATOR
	Copyright 2007 ir. Marc Dendooven

 First Blitz3D Conversion by Jimmy

 Bugfixed, commented and improved by me.

 VIC 20 code by me.

 For more information on this program and other projects please visit my site at ..

	 http://www.themotionstore.com/leeedavison/index.html

 .. or ..

	 http://members.multimania.co.uk/leeedavison/index.html

