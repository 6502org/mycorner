
 This code was originally  ED64 - HOW TO WRITE A COMMODORE 64 EMULATOR
					Copyright 2007 ir. Marc Dendooven

 Blitz3D Conversion by Jimmy

 Bugfixes and a thorough tidy up by me


 For more information on this program and other projects please visit my site at ..

	 http://www.themotionstore.com/leeedavison/index.html

 .. or ..

	 http://members.multimania.co.uk/leeedavison/index.html

